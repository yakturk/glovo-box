This is a Java8 Spring Boot project. Get familiar with it and import it into your IDE.

- Make sure you're able to execute it by using `./run` or just running `com.glovoapp.backender.API::main()`
- Make sure you know how to add a Unit test to the project using Junit5
- Make sure you know how to execute the test suite
- Make sure you know how to add a new endpoint
- Make sure you know how to use application.properties and how to inject configuration

After that, start with the [WORDING](./WORDING.md). Good luck :)!


