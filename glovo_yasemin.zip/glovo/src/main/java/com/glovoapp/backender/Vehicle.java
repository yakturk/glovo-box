package com.glovoapp.backender;

enum Vehicle {
    MOTORCYCLE, BICYCLE, ELECTRIC_SCOOTER
}
